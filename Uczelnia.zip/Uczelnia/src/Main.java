import java.util.ArrayList;
public class Main {
    static ArrayList<Kursy> wszystkieKursy = new ArrayList<Kursy>();
    static ArrayList<PracownikUczelni> wszyscyPracownicy = new ArrayList<PracownikUczelni>();
    static ArrayList<Student> wszyscyStudenci = new ArrayList<Student>();

    public static void wyswietlKursy(){
        System.out.println("Wszystkie kursy: ");
        for(int i = 0; i < wszystkieKursy.size(); i++){
            System.out.println(wszystkieKursy.get(i).toString());
        }
    }
    public static void wyswietlPracownikow(){
        System.out.println("Wszyscy prowadzacy: ");
        for(int i = 0; i < wszyscyPracownicy.size(); i++){
            System.out.println(wszyscyPracownicy.get(i).toString());
        }
    }
    public static PracownikUczelni wyszukajPracownika(String ciag){
        for(int i = 0; i < wszyscyPracownicy.size(); i++){
            if(wszyscyPracownicy.get(i).getImie() == ciag){
                return wszyscyPracownicy.get(i);
            }
            else if(wszyscyPracownicy.get(i).getNazwisko() == ciag){
                return wszyscyPracownicy.get(i);
            }
            else if(wszyscyPracownicy.get(i).getPesel() == ciag){
                return wszyscyPracownicy.get(i);
            }
        }
        return null;
    }
    public static PracownikUczelni wyszukajPracownika(int liczba){
        for(int i = 0; i < wszyscyPracownicy.size(); i++){
            if(wszyscyPracownicy.get(i).stazPracy == liczba){
                return wszyscyPracownicy.get(i);
            }
            else if(wszyscyPracownicy.get(i).pensja == liczba){
                return wszyscyPracownicy.get(i);
            }
        }
        return null;
    }
    public static Student wyszukajStudenta(String dane){
        for(int i = 0; i < wszyscyStudenci.size(); i++){
            if(wszyscyStudenci.get(i).getImie() == dane) return wszyscyStudenci.get(i);
            else if(wszyscyStudenci.get(i).getNazwisko() == dane) return wszyscyStudenci.get(i);
            else if(wszyscyStudenci.get(i).getIndeks() == dane) return wszyscyStudenci.get(i);
        }
        return null;
    }
    public static ArrayList<Student> wyszukajStudentowDanegoRoku(int rokStudiow){
        ArrayList<Student> pom = new ArrayList<Student>();
        for(int i = 0; i < wszyscyStudenci.size(); i++){
            if(wszyscyStudenci.get(i).getRok() == rokStudiow) pom.add(wszyscyStudenci.get(i));
        }
        return null;
    }
    public static ArrayList<Student> wyszukajStudentowDanegoKursu(String nazwaKursu){
        ArrayList<Student> pom = new ArrayList<Student>();
        for(int i = 0; i < wszyscyStudenci.size(); i++){
            for(int j = 0; j < wszyscyStudenci.get(i).getKursy().size(); i++){
                if(wszyscyStudenci.get(i).getKursy().get(j).nazwaKursu == nazwaKursu){
                    pom.add(wszyscyStudenci.get(i));
                }
            }
        }
        return null;
    }

    public static void main(String[] args) {
        //Prowadzacy
        PracownikBadawczoDydaktyczny KMichalik = new PracownikBadawczoDydaktyczny("Krzysztof","Michalik","078472848",45,"m",20,7000,"Wykladowca",12);
        PracownikBadawczoDydaktyczny TKulczycki = new PracownikBadawczoDydaktyczny("Tadeusz","Kulczycki", "085746382",55,"m",30,7500,"Wykladowca",20);
        PracownikBadawczoDydaktyczny KBilewicz = new PracownikBadawczoDydaktyczny("Krzysztof", "Bilewicz","578375849",53,"m",15,7200,"Wykladowca",10);
        wszyscyPracownicy.add(KMichalik); wszyscyPracownicy.add(TKulczycki); wszyscyPracownicy.add(KBilewicz);


        //Kursy
        Kursy AlgebraZGA = new Kursy("Algebra z Geometria Analityczna", KMichalik,6);
        Kursy AM1 = new Kursy("Analiza Matematyczna 1", TKulczycki, 6);
        Kursy OSK = new Kursy("Organizacja Systemow Komputerowych", KBilewicz, 3);

        //Kursy dla informatyki stosowanej
        ArrayList<Kursy> IST= new ArrayList<Kursy>();
        IST.add(AlgebraZGA); wszystkieKursy.add(AlgebraZGA); IST.add(AM1); wszystkieKursy.add(AM1); IST.add(OSK); wszystkieKursy.add(OSK);

        Student a = new Student("Jedrzej", "Kociekci", "03242808478",19,"m","272711",1,IST,false,true,true);
        Student b = new Student("Jan", "Kowalski", "032456473", 19,"m","275612",1,IST, false, true,true);
        wszyscyStudenci.add(a); wszyscyStudenci.add(b);

    wyswietlKursy();
    wyswietlPracownikow();

    


    }
}