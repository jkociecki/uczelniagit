public class Kursy {
    String nazwaKursu;
    PracownikBadawczoDydaktyczny prowadzacy;
    int punktyECTS;

    public Kursy(String nazwaKursu, PracownikBadawczoDydaktyczny pracownik, int punktyECTS){
        this.nazwaKursu = nazwaKursu;
        this.prowadzacy = pracownik;
        this.punktyECTS = punktyECTS;
    }

    public String toString(){
        return nazwaKursu + " , "+ prowadzacy.imie + " , "+prowadzacy.nazwisko+ " , "+punktyECTS;
    }


}
