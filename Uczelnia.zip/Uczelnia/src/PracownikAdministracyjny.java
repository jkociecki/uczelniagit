public class PracownikAdministracyjny extends PracownikUczelni{
    String stanowiskoPracy;
    int nadgodziny;

    public PracownikAdministracyjny(){
        super();
        stanowiskoPracy = "";
        nadgodziny = 0;
    }
    public PracownikAdministracyjny(String imie, String nazwisko, String pesel, int wiek, String plec,int stazPracy, double pensja,String stanowiskoPracy, int nadgodziny){
        super(imie,nazwisko,pesel,wiek,plec,stazPracy,pensja);
        this.stanowiskoPracy = stanowiskoPracy;
        this.nadgodziny = nadgodziny;
    }

}
