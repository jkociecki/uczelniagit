public abstract class PracownikUczelni extends Osoba {
    String stanowisko;
    int stazPracy;
    double pensja;

    public PracownikUczelni(){
        super();
        stazPracy = 0;
        pensja = 0;
    }

    public PracownikUczelni(String imie, String nazwisko, String pesel, int wiek, String plec,int stazPracy, double pensja){
        super(imie, nazwisko, pesel, wiek, plec);
        this.stazPracy = stazPracy;
        this.pensja = pensja;
    }
    public String toString(){
        return super.toString() +" , " + stanowisko + " , " + stazPracy + " , "+ pensja;
    }
    public String getStanowisko() {
        return stanowisko;
    }
}
