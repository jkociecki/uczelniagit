import java.util.ArrayList;

public class Student extends Osoba{
    String indeks;
    int rok;
    ArrayList<Kursy> kursy = new ArrayList<Kursy>();
    boolean czyErasmus;
    boolean czyPierwszyStopien;
    boolean czyStacjonarne;

    public Student(String imie, String nazwisko, String pesel, int wiek, String plec, String indeks, int rok, ArrayList<Kursy> kursy, boolean czyErasmus, boolean czyPierwszyStopien, boolean czyStacjonarne){
        super(imie, nazwisko, pesel, wiek, plec);
        this.kursy = kursy;
        this.indeks = indeks;
        this.rok = rok;
        this.czyPierwszyStopien = czyPierwszyStopien;
        this.czyStacjonarne = czyStacjonarne;
    }

    @Override
    public String getImie() {
        return super.getImie();
    }

    public String getIndeks() {
        return indeks;
    }

    public int getRok() {
        return rok;
    }

    public ArrayList<Kursy> getKursy() {
        return kursy;
    }
}
