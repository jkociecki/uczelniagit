public class PracownikBadawczoDydaktyczny extends PracownikUczelni{
    String stanowiskoPracy;
    int liczbaPublikacji;

    public PracownikBadawczoDydaktyczny(){
        super();
        stanowiskoPracy = "";
        liczbaPublikacji = 0;
    }
    public PracownikBadawczoDydaktyczny(String imie, String nazwisko, String pesel, int wiek, String plec,int stazPracy, double pensja, String stanowiskoPracy, int liczbaPublikacji){
        super(imie, nazwisko, pesel, wiek, plec, stazPracy, pensja);
        this.stanowiskoPracy = stanowiskoPracy;
        this.liczbaPublikacji = liczbaPublikacji;
    }

    public String toString(){
        return super.toString() + " , " + stanowiskoPracy + " , " + liczbaPublikacji;
    }


}
